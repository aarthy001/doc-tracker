/* Supabase client configuration */

const SUPABASE_URL = 'https://pdlaiddpaoonypsxxnoa.supabase.co';
const SUPABASE_ANON = 'sb_publishable_SsoR5Gae8NHPBv-EdLyYkg_SbeBkI0H';

const supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_ANON
);