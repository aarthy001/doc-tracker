/* =============================================
   PERSONAL DOCUMENT & WARRANTY TRACKER
   script.js — all app logic
   ============================================= */

'use strict';

// ──────────────────────────────────────────────
// CONSTANTS & HELPERS
// ──────────────────────────────────────────────

const STORAGE_KEY = 'docTracker_documents';
const EXPIRING_SOON_DAYS = 30; // warn if expiry is within this many days

/** Return today as a YYYY-MM-DD string (local time). */
function today() {
  const d = new Date();
  return d.toISOString().split('T')[0];
}

/** Generate a simple unique id. */
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/**
 * Format a YYYY-MM-DD string into a readable date (e.g. "12 Oct 2026").
 * Returns "—" if the value is empty.
 */
function formatDate(isoStr) {
  if (!isoStr) return '—';
  const [y, m, d] = isoStr.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
  });
}

/**
 * Days remaining until an expiry date (negative = already expired).
 * Returns null if no expiry date is provided.
 */
function daysUntilExpiry(expiryIso) {
  if (!expiryIso) return null;
  const [y, m, d] = expiryIso.split('-').map(Number);
  const expiry = new Date(y, m - 1, d);
  const todayDate = new Date();
  todayDate.setHours(0, 0, 0, 0);
  return Math.round((expiry - todayDate) / 86_400_000);
}

/**
 * Return status object for a document: { label, css, badge }
 */
function getStatus(expiryIso) {
  const days = daysUntilExpiry(expiryIso);
  if (days === null)      return { label: 'No expiry',      css: 'valid',    badge: 'status-valid',    cardClass: '' };
  if (days < 0)           return { label: 'Expired',        css: 'expired',  badge: 'status-expired',  cardClass: 'expired' };
  if (days <= EXPIRING_SOON_DAYS)
                          return { label: `${days}d left`,  css: 'expiring', badge: 'status-expiring', cardClass: 'expiring-soon' };
  return                         { label: 'Valid',           css: 'valid',    badge: 'status-valid',    cardClass: '' };
}

// ──────────────────────────────────────────────
// LOCAL STORAGE
// ──────────────────────────────────────────────

function loadDocuments() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch {
    return [];
  }
}

function saveDocuments(docs) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
}

// ──────────────────────────────────────────────
// SAMPLE DATA  (only loaded once, on first visit)
// ──────────────────────────────────────────────

const SAMPLE_DATA = [
  {
    id: 'sample1',
    name: 'Samsung TV Warranty',
    category: 'Warranty',
    issueDate: '2023-03-15',
    expiryDate: '2026-03-15',
    notes: 'Model: UA55AU7700. Keep receipt in kitchen drawer.',
  },
  {
    id: 'sample2',
    name: "Driver's Licence",
    category: 'Licence',
    issueDate: '2021-06-01',
    expiryDate: '2031-06-01',
    notes: 'Licence No: DL-4892301.',
  },
  {
    id: 'sample3',
    name: 'Home Insurance',
    category: 'Insurance',
    issueDate: '2026-01-01',
    expiryDate: '2026-11-30',
    notes: 'Policy No: HI-2026-77821. Insurer: SafeGuard Ltd.',
  },
  {
    id: 'sample4',
    name: 'Laptop Warranty (Expired)',
    category: 'Warranty',
    issueDate: '2022-08-10',
    expiryDate: '2024-08-10',
    notes: 'Dell XPS 15. Already expired — kept for records.',
  },
  {
    id: 'sample5',
    name: 'Car Insurance',
    category: 'Insurance',
    issueDate: '2026-09-01',
    expiryDate: '2026-11-10',
    notes: 'Comprehensive cover. Policy No: CI-773291.',
  },
];

function seedSampleData() {
  if (loadDocuments().length === 0) {
    saveDocuments(SAMPLE_DATA);
  }
}

// ──────────────────────────────────────────────
// DOM REFERENCES
// ──────────────────────────────────────────────

const cardsGrid     = document.getElementById('cardsGrid');
const emptyState    = document.getElementById('emptyState');
const searchInput   = document.getElementById('searchInput');
const filterBtns    = document.querySelectorAll('.filter-btn');

const statTotal         = document.getElementById('statTotal');
const statExpiringSoon  = document.getElementById('statExpiringSoon');
const statExpired       = document.getElementById('statExpired');
const statTotalWarranties  = document.getElementById('statTotalWarranties');

// Add / Edit modal
const modalOverlay  = document.getElementById('modalOverlay');
const modalTitle    = document.getElementById('modalTitle');
const docForm       = document.getElementById('docForm');
const docId         = document.getElementById('docId');
const docName       = document.getElementById('docName');
const docCategory   = document.getElementById('docCategory');
const issueDate     = document.getElementById('issueDate');
const expiryDate    = document.getElementById('expiryDate');
const docNotes      = document.getElementById('docNotes');

const docNameError      = document.getElementById('docNameError');
const docCategoryError  = document.getElementById('docCategoryError');
const expiryDateError   = document.getElementById('expiryDateError');

// Delete modal
const deleteOverlay     = document.getElementById('deleteOverlay');
const deleteDocName     = document.getElementById('deleteDocName');
const confirmDeleteBtn  = document.getElementById('confirmDeleteBtn');

// Toast
const toast = document.getElementById('toast');

// ──────────────────────────────────────────────
// STATE
// ──────────────────────────────────────────────

let currentFilter  = 'All';
let pendingDeleteId = null;

// ──────────────────────────────────────────────
// RENDER
// ──────────────────────────────────────────────

function render() {
  const docs   = loadDocuments();
  const query  = searchInput.value.trim().toLowerCase();

  // Apply search + filter
  const visible = docs.filter(doc => {
    const matchFilter = currentFilter === 'All' || doc.category === currentFilter;
    const matchSearch = !query
      || doc.name.toLowerCase().includes(query)
      || doc.category.toLowerCase().includes(query)
      || (doc.notes || '').toLowerCase().includes(query);
    return matchFilter && matchSearch;
  });

  // Update stats (always based on both documents and warranties)
  updateStats();

  // Render cards
  cardsGrid.innerHTML = '';
  if (visible.length === 0) {
    emptyState.classList.remove('hidden');
  } else {
    emptyState.classList.add('hidden');
    visible.forEach(doc => cardsGrid.appendChild(createCard(doc)));
  }
}

function updateStats() {
  const docs       = loadDocuments();
  const warranties = loadWarranties();  // uses Stage 2 function

  let expiringSoon = 0, expired = 0;

  // Count across all document expiry dates
  docs.forEach(function (doc) {
    const days = daysUntilExpiry(doc.expiryDate);
    if (days === null) return;           // no expiry date → not counted
    if (days < 0)                  expired++;
    else if (days <= EXPIRING_SOON_DAYS) expiringSoon++;
  });

  // Count across all warranty end dates
  warranties.forEach(function (w) {
    const days = daysUntilExpiry(w.endDate);
    if (days === null) return;           // no end date → not counted
    if (days < 0)                  expired++;
    else if (days <= EXPIRING_SOON_DAYS) expiringSoon++;
  });

  statTotal.textContent           = docs.length;
  statTotalWarranties.textContent = warranties.length;
  statExpiringSoon.textContent    = expiringSoon;
  statExpired.textContent         = expired;
}

function createCard(doc) {
  const status = getStatus(doc.expiryDate);

  const card = document.createElement('article');
  card.className = `doc-card ${status.cardClass}`;
  card.setAttribute('data-id', doc.id);

  card.innerHTML = `
    <div class="card-top">
      <span class="card-name">${escapeHtml(doc.name)}</span>
      <div class="card-actions">
        <button class="btn-icon edit"   title="Edit"   data-action="edit"   data-id="${doc.id}">✏️</button>
        <button class="btn-icon delete" title="Delete" data-action="delete" data-id="${doc.id}">🗑️</button>
      </div>
    </div>

    <span class="tag tag-${doc.category}">${doc.category}</span>

    <div class="card-dates">
      ${doc.issueDate ? `<div class="date-row"><span class="icon">📅</span> Issued: <strong>${formatDate(doc.issueDate)}</strong></div>` : ''}
      ${doc.expiryDate
          ? `<div class="date-row"><span class="icon">⏰</span> Expires: <strong>${formatDate(doc.expiryDate)}</strong></div>`
          : '<div class="date-row"><span class="icon">♾️</span> No expiry date set</div>'}
    </div>

    <span class="status-badge ${status.badge}">
      ${statusIcon(status.css)} ${status.label}
    </span>

    ${doc.notes ? `<p class="card-notes">📝 ${escapeHtml(doc.notes)}</p>` : ''}
  `;

  return card;
}

function statusIcon(css) {
  return css === 'expired'  ? '🔴'
       : css === 'expiring' ? '🟡'
       : '🟢';
}

/** Prevent XSS when inserting user text into innerHTML. */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ──────────────────────────────────────────────
// MODAL — OPEN / CLOSE
// ──────────────────────────────────────────────

function openAddModal() {
  clearForm();
  docId.value    = '';
  modalTitle.textContent = 'Add Document';
  document.getElementById('saveBtn').textContent = 'Save Document';
  // Default expiry date max is far future — no restriction for add
  expiryDate.min = today();
  showModal(modalOverlay);
  docName.focus();
}

function openEditModal(id) {
  const docs = loadDocuments();
  const doc  = docs.find(d => d.id === id);
  if (!doc) return;

  clearForm();
  docId.value           = doc.id;
  docName.value         = doc.name;
  docCategory.value     = doc.category;
  issueDate.value       = doc.issueDate  || '';
  expiryDate.value      = doc.expiryDate || '';
  docNotes.value        = doc.notes      || '';
  modalTitle.textContent = 'Edit Document';
  document.getElementById('saveBtn').textContent = 'Update Document';
  expiryDate.min = '';  // Allow editing past expiry on existing docs
  showModal(modalOverlay);
  docName.focus();
}

function closeModal() {
  hideModal(modalOverlay);
  clearForm();
}

function showModal(overlay) {
  overlay.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function hideModal(overlay) {
  overlay.classList.add('hidden');
  document.body.style.overflow = '';
}

function clearForm() {
  docForm.reset();
  [docName, docCategory, expiryDate].forEach(el => el.classList.remove('invalid'));
  [docNameError, docCategoryError, expiryDateError].forEach(el => el.textContent = '');
}

// ──────────────────────────────────────────────
// FORM VALIDATION
// ──────────────────────────────────────────────

function validateForm() {
  let valid = true;

  // Name
  if (!docName.value.trim()) {
    setError(docName, docNameError, 'Document name is required.');
    valid = false;
  } else {
    clearError(docName, docNameError);
  }

  // Category
  if (!docCategory.value) {
    setError(docCategory, docCategoryError, 'Please select a category.');
    valid = false;
  } else {
    clearError(docCategory, docCategoryError);
  }

  // Expiry date
  if (!expiryDate.value) {
    setError(expiryDate, expiryDateError, 'Expiry date is required.');
    valid = false;
  } else if (issueDate.value && expiryDate.value < issueDate.value) {
    setError(expiryDate, expiryDateError, 'Expiry date must be after the issue date.');
    valid = false;
  } else {
    clearError(expiryDate, expiryDateError);
  }

  return valid;
}

function setError(field, errorEl, msg) {
  field.classList.add('invalid');
  errorEl.textContent = msg;
}

function clearError(field, errorEl) {
  field.classList.remove('invalid');
  errorEl.textContent = '';
}

// ──────────────────────────────────────────────
// CRUD OPERATIONS
// ──────────────────────────────────────────────

function handleFormSubmit(e) {
  e.preventDefault();
  if (!validateForm()) return;

  const docs = loadDocuments();
  const id   = docId.value;

  const docData = {
    id:         id || uid(),
    name:       docName.value.trim(),
    category:   docCategory.value,
    issueDate:  issueDate.value  || '',
    expiryDate: expiryDate.value || '',
    notes:      docNotes.value.trim(),
  };

  if (id) {
    // Edit
    const idx = docs.findIndex(d => d.id === id);
    if (idx !== -1) docs[idx] = docData;
    showToast('Document updated successfully.', 'success');
  } else {
    // Add
    docs.unshift(docData);
    showToast('Document added successfully.', 'success');
  }

  saveDocuments(docs);
  closeModal();
  render();
}

function requestDelete(id) {
  const docs = loadDocuments();
  const doc  = docs.find(d => d.id === id);
  if (!doc) return;
  pendingDeleteId = id;
  deleteDocName.textContent = doc.name;
  showModal(deleteOverlay);
}

function confirmDelete() {
  if (!pendingDeleteId) return;
  const docs    = loadDocuments().filter(d => d.id !== pendingDeleteId);
  saveDocuments(docs);
  pendingDeleteId = null;
  hideModal(deleteOverlay);
  showToast('Document deleted.', 'success');
  render();
}

// ──────────────────────────────────────────────
// TOAST
// ──────────────────────────────────────────────

let toastTimer = null;

function showToast(msg, type = 'info') {
  clearTimeout(toastTimer);
  toast.textContent  = msg;
  toast.className    = `toast toast-${type}`;
  toast.classList.remove('hidden');
  toastTimer = setTimeout(() => toast.classList.add('hidden'), 3000);
}

// ──────────────────────────────────────────────
// EVENT LISTENERS
// ──────────────────────────────────────────────

// Open add modal — context-aware: opens document or warranty form depending on active tab
document.getElementById('openModalBtn').addEventListener('click', function () {
  const activePage = document.querySelector('.nav-tab.active').dataset.page;
  if (activePage === 'warranties') {
    openAddWarrantyModal();
  } else {
    openAddModal();
  }
});
document.getElementById('emptyAddBtn').addEventListener('click', openAddModal);

// Close add/edit modal
document.getElementById('closeModalBtn').addEventListener('click', closeModal);
document.getElementById('cancelBtn').addEventListener('click', closeModal);

// Close modal by clicking overlay background
modalOverlay.addEventListener('click', e => {
  if (e.target === modalOverlay) closeModal();
});

// Form submit
docForm.addEventListener('submit', handleFormSubmit);

// Delete modal
document.getElementById('closeDeleteBtn').addEventListener('click', () => {
  pendingDeleteId = null;
  hideModal(deleteOverlay);
});
document.getElementById('cancelDeleteBtn').addEventListener('click', () => {
  pendingDeleteId = null;
  hideModal(deleteOverlay);
});
deleteOverlay.addEventListener('click', e => {
  if (e.target === deleteOverlay) {
    pendingDeleteId = null;
    hideModal(deleteOverlay);
  }
});
confirmDeleteBtn.addEventListener('click', confirmDelete);

// Card action buttons (edit / delete) — event delegation
cardsGrid.addEventListener('click', e => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;
  const { action, id } = btn.dataset;
  if (action === 'edit')   openEditModal(id);
  if (action === 'delete') requestDelete(id);
});

// Search input
searchInput.addEventListener('input', render);

// Filter buttons
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    render();
  });
});

// Keyboard: Escape closes any open modal
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (!modalOverlay.classList.contains('hidden'))  closeModal();
  if (!deleteOverlay.classList.contains('hidden')) {
    pendingDeleteId = null;
    hideModal(deleteOverlay);
  }
});

// ──────────────────────────────────────────────
// INIT
// ──────────────────────────────────────────────

seedSampleData();
render();

// ──────────────────────────────────────────────
// STAGE 1 — TAB NAVIGATION
// ──────────────────────────────────────────────

/**
 * initTabs()
 * Wires up the three nav tabs (Dashboard / Documents / Warranties).
 * Clicking a tab:
 *   1. Moves the .active class to that tab button.
 *   2. Shows the matching .page-section, hides the others.
 *   3. Updates the header "+ Add" button label.
 *
 * The existing openModalBtn click listener (openAddModal) is left
 * completely unchanged — it still opens the document Add/Edit modal
 * from the Dashboard and Documents tabs as expected.
 */
function initTabs() {
  const tabs      = document.querySelectorAll('.nav-tab');
  const sections  = document.querySelectorAll('.page-section');
  const headerBtn = document.getElementById('openModalBtn');

  // Label for the header button on each tab
  const btnLabels = {
    dashboard:  '+ Add Document',
    documents:  '+ Add Document',
    warranties: '+ Add Warranty',  // will be wired up fully in Stage 2
  };

  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      const targetPage = tab.dataset.page;

      // 1. Update tab button styles
      tabs.forEach(function (t) {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      // 2. Show matching section, hide all others
      sections.forEach(function (section) {
        if (section.id === 'page-' + targetPage) {
          section.classList.add('active');
        } else {
          section.classList.remove('active');
        }
      });

      // 3. Update header button label
      headerBtn.textContent = btnLabels[targetPage] || '+ Add Document';
    });
  });
}

// Call initTabs() once — the <script> tag is at the bottom of <body>
// so all HTML elements are already available at this point.
initTabs();

// ══════════════════════════════════════════════
// STAGE 2 — WARRANTY MANAGEMENT
// ══════════════════════════════════════════════

// ──────────────────────────────────────────────
// WARRANTY STORAGE
// ──────────────────────────────────────────────

const WARRANTY_KEY = 'docTracker_warranties'; // separate from docTracker_documents

function loadWarranties() {
  try {
    return JSON.parse(localStorage.getItem(WARRANTY_KEY)) || [];
  } catch {
    return [];
  }
}

function saveWarranties(warranties) {
  localStorage.setItem(WARRANTY_KEY, JSON.stringify(warranties));
}

// ──────────────────────────────────────────────
// WARRANTY STATUS
// Uses the shared getStatus() and daysUntilExpiry() helpers already defined above.
// Active   : more than 30 days remaining
// Expiring : 0–30 days remaining (including today, days === 0)
// Expired  : end date is before today (days < 0)
// ──────────────────────────────────────────────

// getStatus(endDate) is already defined and handles all three cases correctly.
// No new status logic needed — we reuse the existing function.

// ──────────────────────────────────────────────
// WARRANTY DOM REFERENCES
// ──────────────────────────────────────────────

const warrantiesGrid        = document.getElementById('warrantiesGrid');
const warrantiesEmptyState  = document.getElementById('warrantiesEmptyState');
const warrantySearchInput   = document.getElementById('warrantySearchInput');

// Warranty Add/Edit modal
const warrantyModalOverlay  = document.getElementById('warrantyModalOverlay');
const warrantyModalTitle    = document.getElementById('warrantyModalTitle');
const warrantyForm          = document.getElementById('warrantyForm');
const warrantyId            = document.getElementById('warrantyId');
const warrantyProductName   = document.getElementById('warrantyProductName');
const warrantyProvider      = document.getElementById('warrantyProvider');
const warrantyStartDate     = document.getElementById('warrantyStartDate');
const warrantyEndDate       = document.getElementById('warrantyEndDate');
const warrantyNotes         = document.getElementById('warrantyNotes');

const warrantyProductNameError = document.getElementById('warrantyProductNameError');
const warrantyProviderError    = document.getElementById('warrantyProviderError');
const warrantyEndDateError     = document.getElementById('warrantyEndDateError');

// Warranty Delete modal
const warrantyDeleteOverlay    = document.getElementById('warrantyDeleteOverlay');
const deleteWarrantyName       = document.getElementById('deleteWarrantyName');
const confirmWarrantyDeleteBtn = document.getElementById('confirmWarrantyDeleteBtn');

// ──────────────────────────────────────────────
// WARRANTY STATE
// ──────────────────────────────────────────────

let pendingDeleteWarrantyId = null;

// ──────────────────────────────────────────────
// RENDER WARRANTIES
// ──────────────────────────────────────────────

function renderWarranties() {
  // Keep dashboard stats current whenever warranties change
  updateStats();

  const warranties = loadWarranties();
  const query = warrantySearchInput.value.trim().toLowerCase();

  const visible = warranties.filter(function (w) {
    if (!query) return true;
    return (
      w.productName.toLowerCase().includes(query) ||
      w.provider.toLowerCase().includes(query) ||
      (w.notes || '').toLowerCase().includes(query)
    );
  });

  warrantiesGrid.innerHTML = '';

  if (visible.length === 0) {
    warrantiesEmptyState.classList.remove('hidden');
  } else {
    warrantiesEmptyState.classList.add('hidden');
    visible.forEach(function (w) {
      warrantiesGrid.appendChild(createWarrantyCard(w));
    });
  }
}

function createWarrantyCard(w) {
  // Reuse getStatus() with the warranty end date — same logic as documents
  const status = getStatus(w.endDate);

  const card = document.createElement('article');
  card.className = 'doc-card ' + status.cardClass;
  card.setAttribute('data-id', w.id);

  card.innerHTML =
    '<div class="card-top">' +
      '<span class="card-name">' + escapeHtml(w.productName) + '</span>' +
      '<div class="card-actions">' +
        '<button class="btn-icon edit" title="Edit warranty" data-waction="edit" data-id="' + w.id + '">✏️</button>' +
        '<button class="btn-icon delete" title="Delete warranty" data-waction="delete" data-id="' + w.id + '">🗑️</button>' +
      '</div>' +
    '</div>' +

    '<div class="warranty-provider-row">' +
      '<span class="warranty-provider-icon">🏢</span>' +
      '<span class="warranty-provider-name">' + escapeHtml(w.provider) + '</span>' +
    '</div>' +

    '<div class="card-dates">' +
      (w.startDate
        ? '<div class="date-row"><span class="icon">📅</span> Start: <strong>' + formatDate(w.startDate) + '</strong></div>'
        : '') +
      (w.endDate
        ? '<div class="date-row"><span class="icon">⏰</span> Ends: <strong>' + formatDate(w.endDate) + '</strong></div>'
        : '<div class="date-row"><span class="icon">♾️</span> No end date set</div>') +
    '</div>' +

    '<span class="status-badge ' + status.badge + '">' +
      statusIcon(status.css) + ' ' + status.label +
    '</span>' +

    (w.notes
      ? '<p class="card-notes">📝 ' + escapeHtml(w.notes) + '</p>'
      : '');

  return card;
}

// ──────────────────────────────────────────────
// WARRANTY MODAL — OPEN / CLOSE
// ──────────────────────────────────────────────

function openAddWarrantyModal() {
  clearWarrantyForm();
  warrantyId.value = '';
  warrantyModalTitle.textContent = 'Add Warranty';
  document.getElementById('saveWarrantyBtn').textContent = 'Save Warranty';
  showModal(warrantyModalOverlay); // reuse existing showModal helper
  warrantyProductName.focus();
}

function openEditWarrantyModal(id) {
  const warranties = loadWarranties();
  const w = warranties.find(function (x) { return x.id === id; });
  if (!w) return;

  clearWarrantyForm();
  warrantyId.value           = w.id;
  warrantyProductName.value  = w.productName;
  warrantyProvider.value     = w.provider;
  warrantyStartDate.value    = w.startDate || '';
  warrantyEndDate.value      = w.endDate   || '';
  warrantyNotes.value        = w.notes     || '';
  warrantyModalTitle.textContent = 'Edit Warranty';
  document.getElementById('saveWarrantyBtn').textContent = 'Update Warranty';
  showModal(warrantyModalOverlay);
  warrantyProductName.focus();
}

function closeWarrantyModal() {
  hideModal(warrantyModalOverlay); // reuse existing hideModal helper
  clearWarrantyForm();
}

function clearWarrantyForm() {
  warrantyForm.reset();
  [warrantyProductName, warrantyProvider, warrantyEndDate].forEach(function (el) {
    el.classList.remove('invalid');
  });
  [warrantyProductNameError, warrantyProviderError, warrantyEndDateError].forEach(function (el) {
    el.textContent = '';
  });
}

// ──────────────────────────────────────────────
// WARRANTY FORM VALIDATION
// ──────────────────────────────────────────────

function validateWarrantyForm() {
  let valid = true;

  // Product name
  if (!warrantyProductName.value.trim()) {
    setError(warrantyProductName, warrantyProductNameError, 'Product name is required.');
    valid = false;
  } else {
    clearError(warrantyProductName, warrantyProductNameError);
  }

  // Provider
  if (!warrantyProvider.value.trim()) {
    setError(warrantyProvider, warrantyProviderError, 'Warranty provider is required.');
    valid = false;
  } else {
    clearError(warrantyProvider, warrantyProviderError);
  }

  // End date required
  if (!warrantyEndDate.value) {
    setError(warrantyEndDate, warrantyEndDateError, 'End date is required.');
    valid = false;
  } else if (warrantyStartDate.value && warrantyEndDate.value < warrantyStartDate.value) {
    // End date must not be before start date
    setError(warrantyEndDate, warrantyEndDateError, 'End date must be on or after the start date.');
    valid = false;
  } else {
    clearError(warrantyEndDate, warrantyEndDateError);
  }

  return valid;
}

// ──────────────────────────────────────────────
// WARRANTY CRUD
// ──────────────────────────────────────────────

function handleWarrantyFormSubmit(e) {
  e.preventDefault();
  if (!validateWarrantyForm()) return;

  const warranties = loadWarranties();
  const id = warrantyId.value;

  const warrantyData = {
    id:          id || uid(),           // uid() reused from existing helpers
    productName: warrantyProductName.value.trim(),
    provider:    warrantyProvider.value.trim(),
    startDate:   warrantyStartDate.value || '',
    endDate:     warrantyEndDate.value   || '',
    notes:       warrantyNotes.value.trim(),
  };

  if (id) {
    const idx = warranties.findIndex(function (x) { return x.id === id; });
    if (idx !== -1) warranties[idx] = warrantyData;
    showToast('Warranty updated successfully.', 'success'); // reuse showToast
  } else {
    warranties.unshift(warrantyData);
    showToast('Warranty added successfully.', 'success');
  }

  saveWarranties(warranties);
  closeWarrantyModal();
  renderWarranties();
}

function requestDeleteWarranty(id) {
  const warranties = loadWarranties();
  const w = warranties.find(function (x) { return x.id === id; });
  if (!w) return;
  pendingDeleteWarrantyId = id;
  deleteWarrantyName.textContent = w.productName;
  showModal(warrantyDeleteOverlay);
}

function confirmDeleteWarranty() {
  if (!pendingDeleteWarrantyId) return;
  const warranties = loadWarranties().filter(function (x) {
    return x.id !== pendingDeleteWarrantyId;
  });
  saveWarranties(warranties);
  pendingDeleteWarrantyId = null;
  hideModal(warrantyDeleteOverlay);
  showToast('Warranty deleted.', 'success');
  renderWarranties();
}

// ──────────────────────────────────────────────
// WARRANTY EVENT LISTENERS
// ──────────────────────────────────────────────

// Warranty form submit
warrantyForm.addEventListener('submit', handleWarrantyFormSubmit);

// Close warranty modal — button and Cancel button
document.getElementById('closeWarrantyModalBtn').addEventListener('click', closeWarrantyModal);
document.getElementById('cancelWarrantyBtn').addEventListener('click', closeWarrantyModal);

// Close warranty modal by clicking the overlay background
warrantyModalOverlay.addEventListener('click', function (e) {
  if (e.target === warrantyModalOverlay) closeWarrantyModal();
});

// Warranty delete modal buttons
document.getElementById('closeWarrantyDeleteBtn').addEventListener('click', function () {
  pendingDeleteWarrantyId = null;
  hideModal(warrantyDeleteOverlay);
});
document.getElementById('cancelWarrantyDeleteBtn').addEventListener('click', function () {
  pendingDeleteWarrantyId = null;
  hideModal(warrantyDeleteOverlay);
});
warrantyDeleteOverlay.addEventListener('click', function (e) {
  if (e.target === warrantyDeleteOverlay) {
    pendingDeleteWarrantyId = null;
    hideModal(warrantyDeleteOverlay);
  }
});
confirmWarrantyDeleteBtn.addEventListener('click', confirmDeleteWarranty);

// Warranty cards grid — edit / delete via event delegation
warrantiesGrid.addEventListener('click', function (e) {
  const btn = e.target.closest('[data-waction]');
  if (!btn) return;
  const action = btn.dataset.waction;
  const id     = btn.dataset.id;
  if (action === 'edit')   openEditWarrantyModal(id);
  if (action === 'delete') requestDeleteWarranty(id);
});

// Warranty search
warrantySearchInput.addEventListener('input', renderWarranties);

// Escape key — close warranty modals (added to existing keydown listener)
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Escape') return;
  if (!warrantyModalOverlay.classList.contains('hidden'))  closeWarrantyModal();
  if (!warrantyDeleteOverlay.classList.contains('hidden')) {
    pendingDeleteWarrantyId = null;
    hideModal(warrantyDeleteOverlay);
  }
});

// ──────────────────────────────────────────────
// WARRANTY INIT
// ──────────────────────────────────────────────

// Render warranties on page load so the grid is ready when the tab is opened
renderWarranties();
