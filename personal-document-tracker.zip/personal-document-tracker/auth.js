/* =============================================
   auth.js
   supabaseClient authentication, data layer, and
   one-time localStorage migration.

   Depends on:
     - supabaseClient-config.js  (loaded first — provides `supabaseClient`)
     - script.js           (loaded after — provides render helpers)
   ============================================= */

'use strict';

// ──────────────────────────────────────────────
// FIELD MAPPING HELPERS
// Translate between localStorage camelCase fields
// and supabaseClient snake_case columns.
// ──────────────────────────────────────────────

/**
 * Convert a localStorage document object → supabaseClient row object.
 * Empty date strings are converted to null (supabaseClient DATE columns
 * reject empty strings).
 */
function docToRow(doc, userId) {
  return {
    user_id:     userId,
    title:       doc.name        || '',
    category:    doc.category    || '',
    issue_date:  doc.issueDate   || null,
    expiry_date: doc.expiryDate  || null,
    notes:       doc.notes       || '',
    // document_number is not in localStorage — leave null
    document_number: null,
    // Store the original local id so we can detect duplicates on re-import
    local_id:    doc.id          || null,
  };
}

/**
 * Convert a supabaseClient documents row → localStorage-style object
 * so all existing render functions work without changes.
 */
function rowToDoc(row) {
  return {
    id:         row.id,           // supabaseClient UUID becomes the app id
    name:       row.title        || '',
    category:   row.category     || '',
    issueDate:  row.issue_date   || '',
    expiryDate: row.expiry_date  || '',
    notes:      row.notes        || '',
  };
}

/**
 * Convert a localStorage warranty object → supabaseClient row object.
 */
function warToRow(w, userId) {
  return {
    user_id:          userId,
    product_name:     w.productName || '',
    brand:            w.provider    || '',
    purchase_date:    w.startDate   || null,
    warranty_expiry:  w.endDate     || null,
    notes:            w.notes       || '',
    // serial_number is not in localStorage — leave null
    serial_number:    null,
    local_id:         w.id          || null,
  };
}

/**
 * Convert a supabaseClient warranties row → localStorage-style object.
 */
function rowToWar(row) {
  return {
    id:          row.id,
    productName: row.product_name    || '',
    provider:    row.brand           || '',
    startDate:   row.purchase_date   || '',
    endDate:     row.warranty_expiry || '',
    notes:       row.notes           || '',
  };
}

// ──────────────────────────────────────────────
// supabaseClient DATA LAYER
// These replace the localStorage load/save calls
// when a user is logged in.
// ──────────────────────────────────────────────

